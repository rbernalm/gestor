-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2018 at 09:14 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `biblioteca`
--

-- --------------------------------------------------------

--
-- Table structure for table `administradores`
--

CREATE TABLE IF NOT EXISTS `administradores` (
  `usuario` varchar(120) NOT NULL,
  `password` varchar(120) NOT NULL,
  `usuarios_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `administradores`
--

INSERT INTO `administradores` (`usuario`, `password`, `usuarios_id`) VALUES
('admin', 'admin', 0),
('alejandro', 'alejandro', 1),
('Juan', '1234', 83069),
('Gracias', 'gracias', 89295);

-- --------------------------------------------------------

--
-- Table structure for table `ejemplares`
--

CREATE TABLE IF NOT EXISTS `ejemplares` (
  `cod_ejemplar` varchar(120) NOT NULL,
  `estado` varchar(120) NOT NULL,
  `libros_ISBN` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ejemplares`
--

INSERT INTO `ejemplares` (`cod_ejemplar`, `estado`, `libros_ISBN`) VALUES
('389160N', 'Bien', '978-84-16047-34-5'),
('663452K', 'Muy usado', '84-450-7033-9'),
('769592H', 'Bueno', '978-84-16047-34-5'),
('804199V', 'Muy bueno', '978-1451508598');

-- --------------------------------------------------------

--
-- Table structure for table `ejemplares_prestamos`
--

CREATE TABLE IF NOT EXISTS `ejemplares_prestamos` (
  `ejemplares_cod_ejemplar` varchar(120) NOT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `prestamos_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ejemplares_prestamos`
--

INSERT INTO `ejemplares_prestamos` (`ejemplares_cod_ejemplar`, `fecha_inicio`, `fecha_fin`, `prestamos_id`) VALUES
('389160N', '2015-12-14', '2015-12-18', 34),
('663452K', '2015-12-15', '2015-12-21', 40);

-- --------------------------------------------------------

--
-- Table structure for table `historial`
--

CREATE TABLE IF NOT EXISTS `historial` (
  `id` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `detalles` varchar(240) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `historial`
--

INSERT INTO `historial` (`id`, `fecha`, `detalles`) VALUES
(99, '2015-12-15 08:49:01', 'Añadido libro con ISBN: <b>789-543-23123</b>'),
(100, '2015-12-15 08:49:32', 'Editado el libro cuyo ISBN es: <b>789-543-23123</b>'),
(101, '2015-12-15 08:49:55', 'Eliminado libro y, con ello ejemplares con isbn: <b>789-543-23123</b>'),
(102, '2015-12-15 08:50:40', 'Creado el usuario cuyo dni es: <b>67834223A</b>'),
(103, '2015-12-15 08:51:08', 'Añadido admin cuyo ID de usuario es: <b>83069</b>'),
(104, '2015-12-15 08:51:35', 'Creado el ejemplar cuyo codigo/isbn es: <b>804199V / 978-1451508598</b>'),
(105, '2015-12-15 08:51:54', 'ejemplar cuyo codigo era: <b>851257B</b> fue eliminado'),
(106, '2015-12-15 08:52:52', 'Se ha añadido el prestamo de tipo <b>normal</b> con el codigo del ejemplar/usuario: <b>663452K/83069</b>'),
(107, '2015-12-15 08:53:00', 'Se ha añadido el prestamo de tipo <b>normal</b> con el codigo del ejemplar/usuario: <b>663452K/1</b>'),
(108, '2015-12-15 08:53:38', 'prestamo cuyo ID era: <b>41</b> fue eliminado');

-- --------------------------------------------------------

--
-- Table structure for table `incidencias`
--

CREATE TABLE IF NOT EXISTS `incidencias` (
  `id` int(11) NOT NULL,
  `asunto` varchar(120) DEFAULT NULL,
  `descripcion` varchar(250) DEFAULT NULL,
  `prestamos_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `incidencias`
--

INSERT INTO `incidencias` (`id`, `asunto`, `descripcion`, `prestamos_id`) VALUES
(2, 'entrega antes', 'El ejemplar fue entregado antes de la fecha de finalizacion', 33);

-- --------------------------------------------------------

--
-- Table structure for table `libros`
--

CREATE TABLE IF NOT EXISTS `libros` (
  `ISBN` varchar(120) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `autor` varchar(120) NOT NULL,
  `paginas` int(11) DEFAULT NULL,
  `CDU` varchar(120) DEFAULT NULL,
  `fecha_publicacion` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `libros`
--

INSERT INTO `libros` (`ISBN`, `titulo`, `autor`, `paginas`, `CDU`, `fecha_publicacion`) VALUES
('84-450-7033-9', 'La comunidad del anillo', 'J.R.R. Tolkien', 568, '', 1978),
('978-1451508598', 'La vida es sueño', 'Pedro Calderón de la Barca', 116, '', 1636),
('978-84-16047-34-5', ' Acceso a datos en aplicaciones web del entorno servidor : programación web en el entorno servidor', 'Carballeira Rodrigo, José Manuel', 216, '', 2014);

-- --------------------------------------------------------

--
-- Table structure for table `prestamos`
--

CREATE TABLE IF NOT EXISTS `prestamos` (
  `id` int(11) NOT NULL,
  `finalizado` tinyint(1) NOT NULL,
  `gratuito` tinyint(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prestamos`
--

INSERT INTO `prestamos` (`id`, `finalizado`, `gratuito`) VALUES
(15, 0, 0),
(16, 0, 0),
(17, 1, 0),
(18, 0, 0),
(21, 0, 0),
(26, 0, 1),
(27, 0, 1),
(32, 0, 1),
(33, 0, 1),
(34, 0, 1),
(35, 0, 1),
(38, 0, 1),
(39, 0, 1),
(40, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `registro`
--

CREATE TABLE IF NOT EXISTS `registro` (
  `id` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `detalles` varchar(240) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registro`
--

INSERT INTO `registro` (`id`, `fecha`, `detalles`) VALUES
(1, '2015-11-26 10:36:55', 'Eliminado libro y, con ello ejemplares con isbn: <b>a</b>'),
(2, '2015-11-26 10:37:03', 'Eliminado libro y, con ello ejemplares con isbn: <b>gg</b>'),
(3, '2015-11-26 10:37:07', 'Eliminado libro y, con ello ejemplares con isbn: <b>test2</b>'),
(4, '2015-11-26 10:37:10', 'Eliminado libro y, con ello ejemplares con isbn: <b>this</b>'),
(5, '2015-11-26 17:26:14', 'Editado el usuario cuyo dni es: <b>46068518R</b>'),
(6, '2015-11-26 18:51:18', 'Se ha añadido el prestamo con el codigo del ejemplar/usuario: <b>978216A/331848</b>'),
(7, '2015-11-26 18:51:34', 'prestamo cuyo ID era: <b>4</b> fue eliminado'),
(8, '2015-11-26 18:52:10', 'prestamo cuyo ID era: <b>5</b> fue eliminado'),
(9, '2015-11-26 18:52:12', 'prestamo cuyo ID era: <b>6</b> fue eliminado'),
(10, '2015-11-26 18:52:57', 'prestamo cuyo ID era: <b>1</b> fue eliminado'),
(11, '2015-11-26 18:53:02', 'prestamo cuyo ID era: <b>2</b> fue eliminado'),
(12, '2015-11-26 18:53:11', 'Se ha añadido el prestamo con el codigo del ejemplar/usuario: <b>978216A/891937</b>'),
(13, '2015-11-26 18:53:20', 'Se ha añadido el prestamo con el codigo del ejemplar/usuario: <b>978216A/1</b>'),
(14, '2015-11-26 18:53:26', 'Se ha añadido el prestamo con el codigo del ejemplar/usuario: <b>527466B/331848</b>'),
(15, '2015-11-26 19:03:12', 'Se ha añadido el prestamo con el codigo del ejemplar/usuario: <b>978216A/1</b>'),
(16, '2015-11-26 19:03:16', 'Se ha añadido el prestamo con el codigo del ejemplar/usuario: <b>978216A/1</b>'),
(17, '2015-11-26 19:06:06', 'Modificacion del prestamo cuyo id es: <b>17</b>'),
(18, '2015-11-26 19:07:02', 'Se ha añadido el prestamo con el codigo del ejemplar/usuario: <b>527466B/1</b>');

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL,
  `DNI` varchar(9) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `apellidos` varchar(120) NOT NULL,
  `domicilio` varchar(255) NOT NULL,
  `curso` varchar(120) NOT NULL,
  `n_contacto` int(11) NOT NULL,
  `correo` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `DNI`, `nombre`, `apellidos`, `domicilio`, `curso`, `n_contacto`, `correo`) VALUES
(0, '-', 'admin', 'admin', '-', '-', 0, '-'),
(1, '46068518R', 'Alejandro', 'Gutierrez', 'Avenida de libia', '2º aplicaciones web', 11223344, 'lyon-17@hotmail.com'),
(83069, '67834223A', 'Juan', 'Juan', 'Avenida de la nada', '-', 987364312, 'delanad@hotmail.com'),
(89295, '416571616', 'Karateka', 'Heisanuatra', 'Diablo II', 'Zy El', 30, 'ka@e.c'),
(166138, '999999999', 'Javier', 'Ramirez', '-', 'Avenida del cario', 608553344, 'javiS14@hotmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `usuarios_prestamos`
--

CREATE TABLE IF NOT EXISTS `usuarios_prestamos` (
  `usuarios_id` int(11) NOT NULL,
  `prestamos_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuarios_prestamos`
--

INSERT INTO `usuarios_prestamos` (`usuarios_id`, `prestamos_id`) VALUES
(1, 17),
(1, 21),
(166138, 33),
(166138, 34),
(166138, 35),
(1, 38),
(1, 39),
(83069, 40);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administradores`
--
ALTER TABLE `administradores`
  ADD PRIMARY KEY (`usuarios_id`);

--
-- Indexes for table `ejemplares`
--
ALTER TABLE `ejemplares`
  ADD PRIMARY KEY (`cod_ejemplar`,`libros_ISBN`),
  ADD KEY `Ejemplares_Libros_FK` (`libros_ISBN`);

--
-- Indexes for table `ejemplares_prestamos`
--
ALTER TABLE `ejemplares_prestamos`
  ADD PRIMARY KEY (`ejemplares_cod_ejemplar`,`prestamos_id`),
  ADD KEY `FK_ASS_5` (`prestamos_id`);

--
-- Indexes for table `historial`
--
ALTER TABLE `historial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `incidencias`
--
ALTER TABLE `incidencias`
  ADD PRIMARY KEY (`id`,`prestamos_id`),
  ADD KEY `prestamos_id` (`prestamos_id`);

--
-- Indexes for table `libros`
--
ALTER TABLE `libros`
  ADD PRIMARY KEY (`ISBN`);

--
-- Indexes for table `prestamos`
--
ALTER TABLE `prestamos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registro`
--
ALTER TABLE `registro`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `DNI` (`DNI`);

--
-- Indexes for table `usuarios_prestamos`
--
ALTER TABLE `usuarios_prestamos`
  ADD PRIMARY KEY (`usuarios_id`,`prestamos_id`),
  ADD KEY `FK_ASS_8` (`prestamos_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `historial`
--
ALTER TABLE `historial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=109;
--
-- AUTO_INCREMENT for table `incidencias`
--
ALTER TABLE `incidencias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `prestamos`
--
ALTER TABLE `prestamos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `registro`
--
ALTER TABLE `registro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `administradores`
--
ALTER TABLE `administradores`
  ADD CONSTRAINT `Administradores_Usuarios_FK` FOREIGN KEY (`usuarios_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ejemplares`
--
ALTER TABLE `ejemplares`
  ADD CONSTRAINT `Ejemplares_Libros_FK` FOREIGN KEY (`libros_ISBN`) REFERENCES `libros` (`ISBN`) ON DELETE CASCADE;

--
-- Constraints for table `ejemplares_prestamos`
--
ALTER TABLE `ejemplares_prestamos`
  ADD CONSTRAINT `FK_ASS_4` FOREIGN KEY (`ejemplares_cod_ejemplar`) REFERENCES `ejemplares` (`cod_ejemplar`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_ASS_5` FOREIGN KEY (`prestamos_id`) REFERENCES `prestamos` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `incidencias`
--
ALTER TABLE `incidencias`
  ADD CONSTRAINT `Incidencias_Prestamos_FK` FOREIGN KEY (`prestamos_id`) REFERENCES `prestamos` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `usuarios_prestamos`
--
ALTER TABLE `usuarios_prestamos`
  ADD CONSTRAINT `FK_ASS_7` FOREIGN KEY (`usuarios_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_ASS_8` FOREIGN KEY (`prestamos_id`) REFERENCES `prestamos` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
